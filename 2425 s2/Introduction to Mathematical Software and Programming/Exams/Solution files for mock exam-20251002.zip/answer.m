clear;clc
%(i)
[a,e]=myExp(2,4);
fprintf('Approximate value = %.4f, error = %.4f\n',a,e)

%(ii)
[a1,e1]=myExp(2,11)
[a2,e2]=myExp(2,12)
% based on the test results, the error is about 1.0083*10^(-5) when n=11, 
% the error is about 1.5321*10^(-6) when n=12.
% therefore, a polynomial with degree n=12 is needed for achieving the
% desired accuracy.