clear;clc
%(i)
arr1=[3,7,3,8,1]
isRepeated(arr1)

%(ii)
arr2=[]
isRepeated(arr2)

%(iii)
arr3=[5]
isRepeated(arr3)

%(iv)
arr4=randi([1,10],1,5)
isRepeated(arr4)