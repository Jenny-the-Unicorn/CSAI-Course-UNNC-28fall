function [approx,error] = myExp(x,n)
approx = 1;
for i=1:n
    approx = approx+x^i/myFactorial(i);
end
error = abs(approx-exp(x));
end