function y = myFactorial(n)
y = 1;
for i=1:n
    y = y*i;
end
end