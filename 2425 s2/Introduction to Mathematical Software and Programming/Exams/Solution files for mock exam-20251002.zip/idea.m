% 1. get the array size "n" and initialize the output variable as "false".
% 2. use a nested For loop to for comparing each two elements in the array:
% if same values are found (when i is not equal to j), update the output
% variable as "true".