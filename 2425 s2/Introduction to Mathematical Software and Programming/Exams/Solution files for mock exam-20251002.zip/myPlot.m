x = linspace(-2*pi,2*pi);
f = 2*sin(2*x).*cos(x);
g = sqrt(exp(-abs(x)));
plot(x,f,'r--',x,g,'b:','LineWidth',2)
xlabel('x-axis')
ylabel('y-axis')
legend('f','g')
grid on
title('Two Curves')