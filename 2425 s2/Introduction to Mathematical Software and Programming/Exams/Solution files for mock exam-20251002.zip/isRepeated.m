function x = isRepeated(arr)
n = length(arr);
x = false;
for i=1:n
    for j=1:n
        if arr(i)==arr(j)&& i~=j
            x = true;
        end
    end
end

end
% Note: this question was asked in your Sample Mid-semester Paper Q20.