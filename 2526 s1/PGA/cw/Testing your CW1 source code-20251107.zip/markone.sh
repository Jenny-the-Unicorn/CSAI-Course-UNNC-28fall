
name="${1/_*/}"
# echo "$name"

cd "$1"


# try to compile
if [ ! -f bookstore.c ]
then
    echo "bookstore.c file does not exist"
    exit
fi

gcc -Wall -lm bookstore.c -o bookstore

# open the code and in emacs (change this for a different editor if you want)
# emacsclient feedback.txt&
#echo
echo
# run the tests, print it to console and tests.output file.
./test-all.sh |tee tests.output
