#!/bin/bash

. ./test-utils.sh

EXE=./bookstore
TNAME="test2"
INPUT="test2.input"
EXPECTED_EXIT=0

blue "----- $TNAME ($ARGS) -----"
output=`timeout -s KILL --preserve-status 5s $EXE $ARGS <$INPUT 2>&1`
ec=$?

echo "$output" > "$TNAME.run"
dout=`diff -b -w -U 99999 $TNAME.expected $TNAME.run`
diffec=$?
#echo "$diffec"
if [ $diffec != 0  ]
then
    red "Difference in output!"
    echo "$dout" > "$TNAME.diff"
    echo "$dout"
else
    green "Output matches"
fi
