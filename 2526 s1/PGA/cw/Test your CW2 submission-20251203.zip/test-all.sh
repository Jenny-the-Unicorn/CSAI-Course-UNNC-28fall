#!/bin/bash

. ./test-utils.sh
white_on_black `pwd`


./test1.sh
./test2.sh

