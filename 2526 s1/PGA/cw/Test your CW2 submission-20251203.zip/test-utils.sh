# printing helpers for terminal

RED="\033[0;31m"
GREEN="\033[0;32m"
BLUE="\033[0;34m"
WHITEBLACKBG="\033[0;97;40m"
RESET="\033[0m"

blue () {
    local var="$*"
    echo -e "$BLUE""$var""$RESET"
}
red () {
    local var="$*"
    echo -e "$RED""$var""$RESET"
}
green () {
    local var="$*"
    echo -e "$GREEN""$var""$RESET"
}
white_on_black () {
    local var="$*"
    echo -e "$WHITEBLACKBG""$var""$RESET"
}