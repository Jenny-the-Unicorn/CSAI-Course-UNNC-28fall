load main.asm,
output-file main.out,
compare-to main.cmp,
output-list RAM[0]%D2.6.2 RAM[1]%D2.6.2 RAM[2]%D2.6.2 RAM[50]%D2.7.2 RAM[51]%D2.7.2 RAM[52]%D2.7.2 RAM[53]%D2.7.2 RAM[54]%D2.7.2;

set PC 0,
set RAM[0] 1,
set RAM[1] 1,
set RAM[2] 0,
set RAM[50] 3,
set RAM[51] 2,
set RAM[52] 5,
set RAM[53] 1,
set RAM[54] 4,
repeat 800 {
  ticktock;
}
output;

set PC 0,
set RAM[0] -2,
set RAM[1] 3,
set RAM[2] 0,
set RAM[50] 3,
set RAM[51] 2,
set RAM[52] 5,
set RAM[53] 1,
set RAM[54] 4,
repeat 800 {
  ticktock;
}
output;

set PC 0,
set RAM[0] 2,
set RAM[1] 3,
set RAM[2] 0,
set RAM[50] 3,
set RAM[51] 2,
set RAM[52] 5,
set RAM[53] 1,
set RAM[54] 4,
repeat 800 {
  ticktock;
}
output;

set PC 0,
set RAM[0] -4,
set RAM[1] 2,
set RAM[2] 0,
set RAM[50] 3,
set RAM[51] 2,
set RAM[52] 5,
set RAM[53] 1,
set RAM[54] 4,
repeat 800 {
  ticktock;
}
output;

set PC 0,
set RAM[0] -3,
set RAM[1] -1,
set RAM[2] 0,
set RAM[50] 3,
set RAM[51] 2,
set RAM[52] 5,
set RAM[53] 1,
set RAM[54] 4,
repeat 800 {
  ticktock;
}
output;

set PC 0,
set RAM[0] -4,
set RAM[1] 5,
set RAM[2] 0,
set RAM[50] -3,
set RAM[51] -2,
set RAM[52] -5,
set RAM[53] -1,
set RAM[54] -4,
repeat 800 {
  ticktock;
}
output;

set PC 0,
set RAM[0] -5,
set RAM[1] 4,
set RAM[2] 0,
set RAM[50] -3,
set RAM[51] -2,
set RAM[52] -5,
set RAM[53] -1,
set RAM[54] -4,
repeat 800 {
  ticktock;
}
output;

set PC 0,
set RAM[0] -5,
set RAM[1] 5,
set RAM[2] 0,
set RAM[50] 3,
set RAM[51] 2,
set RAM[52] 5,
set RAM[53] 1,
set RAM[54] 4,
repeat 800 {
  ticktock;
}
output;

set PC 0,
set RAM[0] 3,
set RAM[1] 3,
set RAM[2] 0,
set RAM[50] 3,
set RAM[51] 2,
set RAM[52] 5,
set RAM[53] 1,
set RAM[54] 4,
repeat 800 {
  ticktock;
}
output;

set PC 0,
set RAM[0] 5,
set RAM[1] -5,
set RAM[2] 0,
set RAM[50] -3,
set RAM[51] -2,
set RAM[52] -5,
set RAM[53] -1,
set RAM[54] -4,
repeat 800 {
  ticktock;
}
output;
